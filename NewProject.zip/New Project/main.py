from flask import Flask, flash
from flask import jsonify, render_template, request, redirect, url_for, session, jsonify, send_from_directory
from flaskext.mysql import MySQL

# Mysql Connection
mysql = MySQL()

app = Flask(__name__)


# Uplaod Images and Documents Folder
UPLOAD_FOLDER = '//static//userData'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# mysql config
app.config["MYSQL_DATABASE_USER"] = "root"
app.config["MYSQL_DATABASE_PASSWORD"] = ''
# app.config["MYSQL_DATABASE_DB"] = "doctorproject"
app.config["MYSQL_DATABASE_DB"] = "familjehem"
app.config["MYSQL_DATABASE_HOST"] = "localhost"
mysql.init_app(app)
app.secret_key = '123456789'

@app.route('/')
def admin():
    return render_template("index.html")







@app.route('/login', methods=["GET","POST"])
def loginn():
    if session.get("sessionusername"):
        return redirect(url_for("home"))
    else:
        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            print(username,password)
            conn = mysql.connect()
            cur = conn.cursor()
            cur.execute(" select * from user where user_name=%s;",[username])
            data = cur.fetchone()
            cur.close()
            conn.close()
            if data != None:
                if data[3] == password:
                    session["sessionusername"] = data[2]
                    session["user_id"] = data[0]
                    return redirect(url_for("home"))
                
                else:
                    session["error"] = "password doesn't match."
                    return redirect(url_for("loginn"))
            else:
                session["error"] = "user not exist."
                error = ""
                if session.get("error"):
                    error = session.get("error")                
                return redirect(url_for("loginn"))

           
        else:
            message = ""
            if session.get("message"):
                message = session.get("message")
                session.pop("message", None)

            error = ""
            if session.get("error"):
                error = session.get("error")
                session.pop("error", None)
            return render_template("login.html", error=error)

@app.route("/logout",methods=["GET","POST"])
def logout():
    session.pop("sessionusername", None)
    return redirect(url_for("loginn"))




# Mobile API's
@app.route("/signin-api", methods=["POST", "GET"])
def signin_api():
    if request.method == "POST":
        if request.is_json:
            data = request.get_json()
            username = data["username"]
            password = data["password"]
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''select sno, name, user_name, password from 
            user where user_name=%s and password=%s;''', [username,password])
            user_data = cursor.fetchone()
            print(user_data)
            cursor.close()
            conn.close()
            if user_data is not None:
                password = user_data[3]
                if password == password:
                    return jsonify({"success":True,"iduser": user_data[0], "name": user_data[1], "user_name":user_data[2]})
                else:
                    return jsonify({"success": False, "error": "Invalid Credentials"})
            else:
                return jsonify({"success": False, "error": "Invalid User or user doesn't exist."})
        else:
            return jsonify({"success": False, "error": "Invalid request not json format."})
    else:
        return jsonify({"success": False, "error": "Invalid request"})





@app.route("/signup-api", methods=["POST", "GET"])
def signup_api():
   if request.method == "POST":
        if request.is_json:
            data = request.get_json()
            name = data["name"]
            usernmae = data["username"]               
            password = data["password"]
            role = data["role"]
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''select sno,user_name from user where user_name=%s;''', [usernmae])
            data_user = cursor.fetchone()
            print(data_user)
            cursor.close()
            conn.close()
            if data_user is None:
                conn = mysql.connect()
                cursor = conn.cursor()
                cursor.execute('''Insert into user (name, user_name, password, role) values (%s, %s, %s, %s);''', [name, usernmae, password,role])
                conn.commit()      
                cursor.close()
                conn.close()
                return jsonify({ "success": True})
            else:
                return jsonify({"success": False, "error": "User already exist with this email id."})
        else:
            return jsonify({"success": False, "error": "Invalid request not json format"})




# users API's
@app.route("/users-api", methods=["POST", "GET"])
def users_api():
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.execute('''select sno, user_name from 
    user ;''')
    user_data = cursor.fetchall()
    print(user_data)
    cursor.close()
    conn.close()
    
    return jsonify({"success":True,"users": user_data})
        
  




#schadule-api
@app.route("/schedule-api", methods=["POST", "GET"])
def schadule():
    if request.method == "POST":
        if request.is_json:
            data = request.get_json()
            title = data["title"] 
            user_id = data["user_id"] 
            user_name = data["user_name"]
            date = data["date"]
            time = data["time"]
            des = data["des"]
            
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''Insert into schadule (title,user_id,user_name,date,time, des) values (%s, %s,%s,%s,%s,%s);''', [title,user_id,user_name,date,time, des])
            conn.commit()      
            cursor.close()
            conn.close()
            return jsonify({ "success": True})
            
        else:
            return jsonify({"success": False, "error": "Invalid request not json format"})
    else:
            return jsonify({"success": False, "error": "Invalid request not json format"})





#schadule-edit-api
@app.route("/schadule-edit-api", methods=["POST", "GET"])
def schadule_edit_api():
    if request.method == "POST":
        if request.is_json:
            data = request.get_json()
            sno = data["sno"] 
            title = data["title"] 
            date_time = data["date_time"]
            des = data["des"]
            des = data["des"]               
            
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''update  schadule set title=%s,time=%s, des=%s where sno=%s;''', [title,date_time, des,sno])
            conn.commit()      
            cursor.close()
            conn.close()
            return jsonify({ "success": True})
            
        else:
            return jsonify({"success": False, "error": "Invalid request not json format"})
    else:
            return jsonify({"success": False, "error": "Invalid request not json format"})



#ASSIGNMENT
@app.route("/assignment-api", methods=["POST", "GET"])
def assignment_api():
    if request.method == "POST":
        if request.is_json:
            data = request.get_json()
            title = data["title"] 
            user_id = data["user_id"] 
            user_name = data["user_name"]
            date = data["date"]
            time = data["time"]
            des = data["des"]
            des = data["des"]               
            
            conn = mysql.connect()
            cursor = conn.cursor()
            cursor.execute('''Insert into assignment (title,user_id,user_name,date,time, des) values (%s, %s,%s,%s,%s,%s);''', [title,user_id,user_name,date,time, des])
            conn.commit()      
            cursor.close()
            conn.close()
            return jsonify({ "success": True})
            
        else:
            return jsonify({"success": False, "error": "Invalid request not json format"})
    else:
            return jsonify({"success": False, "error": "Invalid request not json format"})
    
   
    


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5009, debug=True)