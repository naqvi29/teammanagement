-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 06:11 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `familjehem`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `sno` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `des` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`sno`, `user_id`, `user_name`, `title`, `date`, `time`, `des`) VALUES
(1, 1, 'admin', 'lunch', '2020-01-01', '10:10:10', 'descccccccc');

-- --------------------------------------------------------

--
-- Table structure for table `schadule`
--

CREATE TABLE `schadule` (
  `sno` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `date` date NOT NULL,
  `des` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schadule`
--

INSERT INTO `schadule` (`sno`, `user_id`, `user_name`, `title`, `time`, `date`, `des`) VALUES
(1, 0, '', 'lunch', '05:38:41', '2020-01-01', 'descccccccc'),
(2, 0, '', '', '05:38:41', '0000-00-00', 'descccccccc'),
(3, 0, '', '', '05:38:41', '2020-01-01', 'descccccccc'),
(4, 0, '', '', '05:38:41', '2020-01-01', 'descccccccc'),
(5, 0, '', '', '05:38:41', '2020-01-01', 'descccccccc'),
(6, 0, '', '', '05:38:41', '2020-01-01', 'desccccasasacccc'),
(7, 0, '', '', '05:38:41', '2020-01-01', 'desccccasas11acccc'),
(8, 0, '', '', '05:38:41', '2020-01-01', 'desccccasas11acccc'),
(9, 0, '', '', '05:38:41', '0200-01-01', 'desccccasas11acccc'),
(10, 0, '', '', '05:38:41', '0200-01-01', 'desccccasas11acccc'),
(11, 0, '', '', '05:38:41', '0000-01-01', 'desccccasas11acccc'),
(12, 0, '', '', '05:38:41', '0000-00-00', 'desccccasas11acccc'),
(13, 0, '', '', '05:38:41', '0000-00-00', 'desccccasas11acccc'),
(14, 0, '', '', '05:38:41', '0000-00-00', 'desccccasas11acccc'),
(15, 0, '', 'lunch', '05:38:41', '2020-01-01', 'descccccccc'),
(16, 0, '', 'lunch', '10:10:10', '2020-01-01', 'descccccccc'),
(17, 1, 'admin', 'lunch', '10:10:10', '2020-01-01', 'descccccccc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `sno` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `user_name` varchar(70) NOT NULL,
  `password` varchar(70) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`sno`, `name`, `user_name`, `password`, `role`) VALUES
(1, 'admin', 'admin', 'admin', 'A'),
(17, 'subadmin', 'subadmin', 'subadmin', 'B'),
(18, 'abc', '123', 'abc', 'User B');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `schadule`
--
ALTER TABLE `schadule`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `schadule`
--
ALTER TABLE `schadule`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
